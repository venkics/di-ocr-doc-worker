import os, uuid, datetime as dt
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import psycopg
from azure.storage.blob import generate_container_sas, ContainerSasPermissions

POSTGRES_URL = os.environ["POSTGRES_URL"]
STORAGE_ACCOUNT_NAME = os.environ["STORAGE_ACCOUNT_NAME"]
STORAGE_ACCOUNT_KEY = os.environ["STORAGE_ACCOUNT_KEY"]
INCOMING_CONTAINER = "incoming"

def get_conn():
    return psycopg.connect(POSTGRES_URL)

app = FastAPI(title="doc-api", version="0.1")

class NewBatchReq(BaseModel):
    patient_id: Optional[str] = None
    sas_ttl_minutes: int = 30

class NewBatchResp(BaseModel):
    batch_id: str
    upload: dict
    status: str

@app.get("/healthz")
def healthz():
    return {"ok": True}

@app.post("/v1/batches", response_model=NewBatchResp)
def create_batch(body: NewBatchReq):
    batch_id = str(uuid.uuid4())
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(
            "INSERT INTO batches (batch_id, patient_id, status) VALUES (%s, %s, 'queued')",
            (batch_id, body.patient_id),
        )
    expiry = dt.datetime.utcnow() + dt.timedelta(minutes=body.sas_ttl_minutes)
    perms = ContainerSasPermissions(write=True, create=True, add=True, list=True)
    sas = generate_container_sas(
        account_name=STORAGE_ACCOUNT_NAME,
        container_name=INCOMING_CONTAINER,
        account_key=STORAGE_ACCOUNT_KEY,
        permission=perms,
        expiry=expiry,
        protocol="https"
    )
    upload_url = f"https://{STORAGE_ACCOUNT_NAME}.blob.core.windows.net/{INCOMING_CONTAINER}?{sas}"
    required_prefix = f"incoming/{batch_id}/"
    return {
        "batch_id": batch_id,
        "status": "queued",
        "upload": {
            "sas_url": upload_url,
            "required_path_prefix": required_prefix,
            "expires_at_utc": expiry.isoformat() + "Z"
        }
    }

@app.get("/v1/batches/{batch_id}")
def get_batch(batch_id: str):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute("SELECT status, created_at, started_at, finished_at FROM batches WHERE batch_id=%s", (batch_id,))
        row = cur.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="batch not found")
        status, created_at, started_at, finished_at = row
        cur.execute("SELECT status, COUNT(*) FROM documents WHERE batch_id=%s GROUP BY status", (batch_id,))
        counts = {r[0]: int(r[1]) for r in cur.fetchall()}
    return {
        "batch_id": batch_id,
        "status": status,
        "created_at": created_at,
        "started_at": started_at,
        "finished_at": finished_at,
        "doc_counts": counts
    }
